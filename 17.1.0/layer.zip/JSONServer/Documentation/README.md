## Documentation for JSONServer can be found on [our wiki](https://github.com/Dyalog/JSONServer/wiki)  
This folder hosts images used on the wiki
