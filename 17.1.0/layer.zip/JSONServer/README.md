# Dyalog JSONServer
A light-weight APL-based HTTP server to call APL code from the net by passing arguments and results as JSON. 
### Documentation
Please see [our wiki](https://github.com/Dyalog/JSONServer/wiki).  
