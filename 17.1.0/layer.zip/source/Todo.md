# Todo
1. Context should have name sapce where all is executed. 
There should be name sapcename in name sapce. The nemsapce should be removed on end of invocation.
2. It is not clear how to have multiple execution in same time. 
==> This is not serveless maner. It should be single threaded i.e. wiyhout async tasks.
3. Loging should be based on numbers not on one number ie there should be APLLOGLEVEL
4. Error handlig should be much better as stack is not correct.