# library-core

This repository contains files which constitute the core application
development library for Dyalog APL. Installations of Dyalog APL from
version 16.0 (June 2017) will contain these files in the folder 
Library/Core below the main Dyalog folder.