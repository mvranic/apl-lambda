# HttpUtils

This will be the documentation for the HttpUtils namespace included with Dyalog APL versions 16.0 and later.

Example of use:
           
      ... to come ...