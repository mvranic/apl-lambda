 # Building distribution file
 If aplsync is checkout (git) at *C:\gitrepos\* then build command from APL session is:
 ```apl 
 ]dbuild 'C:\gitrepos\aplasync'
 ``` 

 Use *)save* to save dws file.
 